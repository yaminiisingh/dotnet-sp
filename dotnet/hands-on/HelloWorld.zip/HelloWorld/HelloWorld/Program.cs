﻿using System;



    class MainClass
    {
        static void Main(string[] args)
        {
       
        Console.WriteLine("Welcome to .Net");
        Console.WriteLine("hii");
        }
    }

