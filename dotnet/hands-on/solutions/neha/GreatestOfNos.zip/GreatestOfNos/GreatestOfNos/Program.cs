﻿using System;



    class GreatestOfNos
    {
        static void Main(string[] args)
        {
        int a, b;
        Console.WriteLine("enter two numbers");
        a = Convert.ToInt32(Console.ReadLine());
        b = Convert.ToInt32(Console.ReadLine());
        if(a>b)
        {
            Console.WriteLine("{0} is Greater", a);
        }
        else
        {
            Console.WriteLine("{0} is Greater", b);
        }


    }
}

