﻿using System; //namespace- library file



    class MainClass //pascal case
    {
        static void Main(string[] args)
        {
        Console.WriteLine("Welcome to .net"); 
        }
    }

