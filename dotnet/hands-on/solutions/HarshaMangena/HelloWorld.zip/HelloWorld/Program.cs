﻿using System;


    class MainClass
    {
        static void Main(string[] args)
        {
        int n1 ,n2 ,n3;
        Console.Write("Number1 :");
        n1 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Number2 :");
        n2 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Number3 :");
        n3 = Convert.ToInt32(Console.ReadLine());
        if ((n1>n2) && (n1>n3))
        {
            Console.WriteLine("{0} is Greatest Number\n",n1);
        }
        else if(n2>n3)
        {
            Console.WriteLine("{0} is Greatest Number\n",n2);
        }
        else if((n1==n2) && (n2==n3)) 
        {
            Console.WriteLine("All numbers are equal\n");
        }
        else
        {
            Console.WriteLine("{0} is Greatest Number\n", n3);
        }


    }
    }
