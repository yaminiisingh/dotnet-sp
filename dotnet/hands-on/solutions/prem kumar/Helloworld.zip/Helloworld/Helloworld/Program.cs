﻿using System;

    class Greatest
    {
        static void Main(string[] args)
        {
            int num1=10, num2=20, num3=30;
            if (num1 > num2)
            {
                if (num1 > num3)
                {
                    Console.Write(num1+" is the largest!\n");
                }
                else
                {
                    Console.Write("Number three is the largest!\n");
                }
            }
            else if (num2 > num3)
                Console.Write("Number two is the largest!\n");
            else
                Console.Write(num3+" is the largest!\n");
        }
    }