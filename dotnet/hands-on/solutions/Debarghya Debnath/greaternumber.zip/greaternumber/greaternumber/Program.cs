﻿using System;


namespace greaternumber
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            Console.WriteLine("enter first num");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter second num");
            b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter third num");
            c = Convert.ToInt32(Console.ReadLine());
            if(a > b & a > c)
            {
                Console.WriteLine("{0} is largest",a);
            }
            else if( b > c & b > a)
            {
                Console.WriteLine("{0} is largest",b);
            }
            else
            {
                Console.WriteLine("{0} is largest",c);
            }


        }
    }
}
