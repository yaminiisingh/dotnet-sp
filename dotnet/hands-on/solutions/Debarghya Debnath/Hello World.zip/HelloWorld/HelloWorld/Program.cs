﻿using System;




    class MainClass
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World");
        }
    }

